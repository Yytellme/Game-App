package com.example.mygame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView txtScore;
    GridView gridV;
    CongCuHoTro congcu = new CongCuHoTro();
    ArrayList arr;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridV = (GridView) findViewById(R.id.gridView);
        gridV.setNumColumns(2);

        setOutlook();
        setListener();
    }

    private void setOutlook(){
        arr = new ArrayList(congcu.taoBangMau(4));
        Adapter adapter = new Adapter(MainActivity.this, R.layout.activity_main, arr);
        gridV.setAdapter(adapter);
    }
    private void setListener(){
        gridV.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                if(position == congcu.dapAn){
                    setOutlook();
                }
            }
        });
    }
}
