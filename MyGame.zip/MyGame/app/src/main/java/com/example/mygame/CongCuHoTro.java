package com.example.mygame;

import java.util.ArrayList;
import java.util.Random;

public class CongCuHoTro {
    static int dapAn;
    Random ran = new Random();
    String string[] = new String[]{"#800080", "8d3280", "0000b1", "#ff0000"};
    public ArrayList<String> taoBangMau(int n){
        ArrayList<String> a = new ArrayList<>();
        int x,y;
        x = ran.nextInt(n); // 0 - n-1
        dapAn = x;
        y = ran.nextInt(3);
        for(int i=0; i<n; i++){
            if(i == x){
                a.add(string[y]);
            }else{
                a.add(string[y+1]);
            }
        }
        return a;
    }
}
