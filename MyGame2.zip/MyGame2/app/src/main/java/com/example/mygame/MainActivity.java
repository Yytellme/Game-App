package com.example.mygame;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    TextView txtScore;
    int score = 0;
    GridView gridV;
    int[] state;

    ProgressBar pb;
    int counter = 3000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridV = (GridView) findViewById(R.id.gridView);
        gridV.setNumColumns(3);

        Random random = new Random();
        Set<Integer> distinctNumbers = new HashSet<>();
        for (int i = 0; i < 9; i++) {
            state[i] = 0;
        }
        while (distinctNumbers.size() < 3) {
            int randomNumber = random.nextInt(9);
            distinctNumbers.add(randomNumber);
            state[randomNumber] = 1;
        }
        ArrayList<String> colors_order = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            if (state[i] == 1) {
                // Get the desired grid
                View gridItem = gridV.getChildAt(i);   // for example, getting the 3rd item
                // Set the background color of the grid
                gridItem.setBackgroundColor(Color.parseColor("#445600"));
            } else {
                // Get the desired grid
                View gridItem = gridV.getChildAt(i);   // for example, getting the 3rd item
                // Set the background color of the grid
                gridItem.setBackgroundColor(Color.parseColor("#441400"));
            }
        }
        //Adapter adapter = new Adapter(MainActivity.this, R.layout.activity_main, colors_order);
        //gridV.setAdapter(adapter);

        countDown();

        for (int i = 0; i < 9; i++) {
            // Get the desired grid
            View gridItem = gridV.getChildAt(i);   // for example, getting the 3rd item
            // Set the background color of the grid
            gridItem.setBackgroundColor(Color.parseColor("#441400"));
        }

        setListener();
    }

    private void setListener() {
        gridV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (state[position] == 1) {
                    score++;
                    txtScore.setText("Score + " + Integer.toString(score));
                    // Get the desired grid
                    View gridItem = gridV.getChildAt(position);   // for example, getting the 3rd item
                    // Set the background color of the grid
                    gridItem.setBackgroundColor(Color.parseColor("#445600"));

                    if(score == 3){
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                        alertDialogBuilder
                                .setMessage("Congratualations! You WIN!\nScore: " + score)
                                .setCancelable(false)
                                .setPositiveButton("New", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }
                } else {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                    alertDialogBuilder
                            .setMessage("GAME OVER!\nScore: " + score)
                            .setCancelable(false)
                            .setPositiveButton("New", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            })
                            .setNegativeButton("EXIT", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finish();
                                }
                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
    }

    public void countDown() {
        pb = (ProgressBar) findViewById(R.id.progressBar);
        final Timer t = new Timer();
        TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                counter--;
                pb.setProgress(counter);

                if (counter == 0)
                    t.cancel();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pb.setVisibility(View.GONE);
                        }
                    });
            }
        };

        t.schedule(tt,0,3000);

    }


}

