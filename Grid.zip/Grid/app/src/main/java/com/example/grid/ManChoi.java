package com.example.grid;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ManChoi extends AppCompatActivity {
    TextView txtScore;
    GridView gridV;
    CongCuHoTro congcu = new CongCuHoTro();
    ArrayList arr;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_m);
        anhXa();
        caiDatGirview();
        setDuLieu();
        setSukien();
    }
    private void anhXa(){
        gridV = (GridView) findViewById(R.id.gridView);
    }
    private void caiDatGirview(){
        gridV.setNumColumns(2);
    }
    private void setDuLieu(){
        arr = new ArrayList(congcu.taoBangMau(4));
        Adapter adapter = new Adapter(ManChoi.this, R.layout.layout_m, arr);
        gridV.setAdapter(adapter);
    }
    private void setSukien(){
        gridV.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                if(position == congcu.dapAn){
                    setDuLieu();
                }
            }
        });
    }
}
